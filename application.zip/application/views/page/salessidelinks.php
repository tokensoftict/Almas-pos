 <div class="be-left-sidebar">
        <div class="left-sidebar-wrapper"><a href="#" class="left-sidebar-toggle">Dashboard</a>
          <div class="left-sidebar-spacer">
            <div class="left-sidebar-scroll">
              <div class="left-sidebar-content">
					<ul class="sidebar-elements">
						 <li><a href="<?php echo base_url('dashboard/pos')  ?>"><span class="icon mdi mdi-shopping-cart-plus"></span>Open POS</a></li>
						  <li><a href="<?php echo base_url('dashboard/add_new_credit')  ?>"><span class="icon mdi mdi-shopping-cart-plus"></span>Credit Sales POS</a></li>
									<li><a href="<?php echo base_url('dashboard/credit')  ?>"><span class="icon mdi mdi-shopping-cart-plus"></span> Daily Credit Sales</a></li>
									 <li> <a href="<?php echo base_url('dashboard/credit_reports'); ?>"><span class="icon mdi mdi-shopping-cart-plus"></span> Monthly Credit Sales</a></li>
									<li><a href="<?php echo base_url('dashboard/due_payment_report')  ?>"><span class="icon mdi mdi-shopping-cart-plus"></span> Due Payment List</a></li>
								
                            <div class="dropdown-tools">
                              <div class="btn-group xs-mt-5 xs-mb-10">
                                <a href="<?php  echo base_url('auth/logout') ?>"   class="btn btn-default"><span class="mdi mdi-power"></span></a>
                                <a href="<?php  echo base_url('dashboard/myprofile') ?>"  class="btn btn-default active"><span class="mdi mdi-face"></span></a>
                              </div>
                            </div>
                          </li>
						 
					</ul>
			  </div>
			</div>
		  </div>
		</div>
	</div>