 <div class="be-left-sidebar">
        <div class="left-sidebar-wrapper"><a href="#" class="left-sidebar-toggle">Dashboard</a>
          <div class="left-sidebar-spacer">
            <div class="left-sidebar-scroll">
              <div class="left-sidebar-content">
					<ul class="sidebar-elements">

							<li>
                            <div class="dropdown-tools">
                              <div class="btn-group xs-mt-5 xs-mb-10">
                                <a href="<?php  echo base_url('auth/logout') ?>"   class="btn btn-default"><span class="mdi mdi-power"></span></a>
                                <a href="<?php  echo base_url('dashboard/myprofile') ?>"  class="btn btn-default active"><span class="mdi mdi-face"></span></a>
                              </div>
                            </div>
                          </li>
						 
					</ul>
			  </div>
			</div>
		  </div>
		</div>
	</div>