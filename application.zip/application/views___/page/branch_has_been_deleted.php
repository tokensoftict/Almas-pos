<html>
	<head>Branch has been Deleted</head>
	<body>
		<h1 style="coloe:red">Sorry!. Your Branch no Longer Exist, Please Contact Administrator to Change your Branch</h1>
		<a href="<?php  base_url("auth/logout") ?>">Log Out here</a>
	</body>
</html>